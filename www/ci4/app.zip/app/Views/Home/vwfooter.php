<?php

?>


<footer>
     
<div class="p-4 bg-dark text-white text-center">
<a href="./index">Home</a>     
<p>Other Footer tag </p>
</div>

</footer>
</body>
</html>