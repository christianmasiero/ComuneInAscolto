

<footer>
     
<div class="p-4 bg-dark text-white text-center">
<a href="/">Home</a>     
<p>Comune In Ascolto</p>
</div>

</footer>
</body>
</html>